import java.util.*;

public class ab_ok{
	public static void main(String[] args){
		Scanner si = new Scanner(System.in);
		while(si.hasNextInt()){
			int a = si.nextInt();
			int b = si.nextInt();
			System.out.println(a+b);
		}
	}
}