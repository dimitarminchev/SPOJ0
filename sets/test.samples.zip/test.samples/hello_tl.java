import java.util.*;

public class hello_tl{
	public static void main(String[] args){
		System.out.println("Hello World");
		while(true){
			System.out.print(".");
		}
	}
}