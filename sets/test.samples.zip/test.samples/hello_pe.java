import java.util.*;

public class hello_pe{
	public static void main(String[] args){
		System.out.print("Hello World");
	}
}